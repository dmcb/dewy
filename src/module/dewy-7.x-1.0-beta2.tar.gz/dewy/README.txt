![Dewy](dewy.png "Dewy")

# Dewy Drupal module

## Installation

* Install via Drush:

		drush dl dewy
		drush en dewy

## Usage

1. [Get a Dewy API key](http://dewy.io).
2. Enable Dewy reporting for your site via Drush, where api_key
is from your Dewy.io account.

		drush dewy-enable api_key
